HTML Form provided by: www.freecontactform.com

Please paste the code from htmlform.htm into your webpage.

Open the file html_form_send.php in your code editor and add your Email Address and Subject Line to the places indicated by code comments.

Enjoy your free script.